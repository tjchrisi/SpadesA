import React, { useState, useEffect } from 'react';
import './App.css';
import { createGameState } from './utils/gameLogic.js';
import GameBoard from './components/GameBoard.jsx';
import BiddingPhase from './components/BiddingPhase.jsx';

function App() {
  const [gameState, setGameState] = useState(null);
  const [gameStarted, setGameStarted] = useState(false);
  
  useEffect(() => {
    if (gameStarted && !gameState) {
      const initialState = createGameState();
      setGameState(initialState);
    }
  }, [gameStarted, gameState]);
  
  const startGame = () => {
    setGameStarted(true);
  };
  
  const resetGame = () => {
    setGameStarted(false);
    setGameState(null);
  };
  
  if (!gameStarted) {
    return (
      <div className="game-container">
        <div className="setup-screen">
          <h1>🏆 Spades - First to 300 Wins! 🏆</h1>
          <h2>4 Player Individual Spades</h2>
          <div className="game-description">
            <p>Experience the classic card game with maximum card visibility!</p>
            <p>Play against 3 AI opponents with strategic gameplay.</p>
            <p>First player to reach 300 points wins the match!</p>
          </div>
          <div className="game-features">
            <h3>Game Features:</h3>
            <ul>
              <li>🎯 Strategic AI opponents</li>
              <li>♠️ Complete Spades rules and scoring</li>
              <li>👁️ Maximum card visibility</li>
              <li>🏆 300-point winning condition</li>
              <li>🔄 Multiple rounds until winner</li>
            </ul>
          </div>
          <button className="start-button" onClick={startGame}>
            🎯 Start New Game
          </button>
        </div>
      </div>
    );
  }
  
  if (!gameState) {
    return (
      <div className="game-container">
        <div className="loading-screen">
          <h1>🎯 Setting up your game...</h1>
          <div className="loading-spinner"></div>
        </div>
      </div>
    );
  }
  
  if (gameState.gamePhase === 'bidding') {
    return (
      <div className="game-container">
        <BiddingPhase 
          gameState={gameState} 
          setGameState={setGameState}
          onStartGame={resetGame}
        />
      </div>
    );
  }
  
  return (
    <div className="game-container">
      <GameBoard 
        gameState={gameState} 
        setGameState={setGameState}
      />
    </div>
  );
}

export default App;